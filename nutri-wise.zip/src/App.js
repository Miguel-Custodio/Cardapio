import React from 'react';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import { ChakraProvider } from '@chakra-ui/react';
import { AuthProvider } from './context/AuthContext';
import { PaymentProvider } from './context/PaymentContext';

import HomePage from './pages/HomePage';
import SignUpPage from './pages/SignUpPage';
import ProfilePage from './pages/ProfilePage';
import MealPlannerPage from './pages/MealPlannerPage';
import PaymentPage from './pages/PaymentPage';
import DashboardPage from './pages/DashboardPage';

const App = () => (
    <ChakraProvider>
        <AuthProvider>
            <PaymentProvider>
                <BrowserRouter>
                    <Routes>
                        <Route path="/" element={<HomePage />} />
                        <Route path="/signup" element={<SignUpPage />} />
                        <Route path="/profile" element={<ProfilePage />} />
                        <Route path="/meal-planner" element={<MealPlannerPage />} />
                        <Route path="/payment" element={<PaymentPage />} />
                        <Route path="/dashboard" element={<DashboardPage />} />
                    </Routes>
                </BrowserRouter>
            </PaymentProvider>
        </AuthProvider>
    </ChakraProvider>
);

export default App;
